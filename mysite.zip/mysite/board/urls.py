from django.urls import path
from .views import *

app_name = "board"

urlpatterns = [
    path('', index, name="index"),
    path('new/', new, name="new"),
    path('<int:pk>/show/',show, name="show"),
    path('<int:pk>/remove/', remove, name="remove"),
]