from distutils.command.upload import upload
from turtle import title
from django.shortcuts import redirect
from django.shortcuts import get_list_or_404, redirect, render
from .models import Post 
from django.core.files.storage import FileSystemStorage

# Create your views here.
def index(request):
    posts = get_list_or_404(Post.objects.order_by('-id'))
    return render(request, 'board/index.html',{
        "posts": posts,
    })

def new(request):
    # 요청 방식이 post인경우 실제 저장 작업을 수행
    if not request.user.is_authenticated:
        return redirect('/login')# 로그인 창으로

    if request.method == "POST":
        print(request.POST)
        if 'image' in request.FILES:
            print("upload")
            # 이미지 첨부의 경우
            upload = request.FILES['image']
            # 저장
            fss = FileSystemStorage()
            file =fss.save(upload.name, upload)

            new_post = Post.objects.create(
                title = request.POST['title'],
                content=request.POST['content'],
                image=file,
                author=request.user,
            )
        else:
            new_post = Post.objects.create(
            title = request.POST['title'],
            content = request.POST['content'],
            author=request.user,
            )
        return redirect('/board')
        # if "image" in request.POST:
    return render(request, 'board/new.html')

def show(request, pk):
    post = Post.objects.get(pk=pk)
    return render(request, 'board/show.html', {
        'post':post,
    })

def remove(request, pk):
    post = Post.objects.get(pk=pk)
    post.delete()
    return redirect("/board") 