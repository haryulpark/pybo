from django.shortcuts import render, redirect
from common.forms import UserForm


# Create your views here.
def index(request):
    return render(request, 'common/index.html') 

#가입 뷰
def signup(request):
    if request.method == "POST":
        form = UserForm(request.POST)
        if form.is_valid(): #검증 결과 확인
            form.save()
            return redirect("/") #홈페이지로 이동

    else:
        form = UserForm()
        return render(request, 'common/signup.html', {"form" : form})